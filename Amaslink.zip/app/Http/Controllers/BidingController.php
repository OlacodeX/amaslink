<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BidingController extends Controller
{
    //
}
