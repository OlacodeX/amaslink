<?php

return [
    'credentials' => [

        'PAYPAL_CLIENT_ID' => env('PAYPAL_CLIENT_ID'),
        'PAYPAL_CLIENT_SECRET' => env('PAYPAL_CLIENT_SECRET'),
        
        'PAYPAL_CURRENCY' => env('PAYPAL_CURRENCY')
    ],
];