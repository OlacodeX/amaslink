<?php $__env->startSection('page_title'); ?>
<?php echo e(config('app.name')); ?> - Best Free Classified Ads
<?php $__env->stopSection(); ?>
<?php echo $__env->make('inc.css.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row main">
        <?php echo $__env->make('inc.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
    <div class="jumbotron text-center">
        <h1 class="text-center">AMASLINK.COM</h1>
        <h3 class="text-center">SELL ANYTHING…</h3>
       <div class="container">
        <p class="text-center">Home – Automobiles – Pets – Furnitures – Cloths – Brands – Services</p>
            <?php echo Form::open(['method' => 'GET', 'action' => 'PagesController@search_result']); ?>

            
            <div class="row">
            <div class="container-fluid form">
            <div class="col-sm-5">
                <div class="form-group">
                    <?php echo e(Form::text('word', '', [ 'class' => 'form-control', 'placeholder' => 'Enter keyword', 'required'])); ?>

                </div>
            </div>
            <div class="col-sm-5">
                <div class="form-group">
                    <?php echo e(Form::text('country', '', [ 'class' => 'form-control', 'placeholder' => 'Enter Country', 'required'])); ?>

                </div>
            </div>
            <div class="col-sm-2 text-center">
                
            <?php echo e(Form::submit('search', ['class' => 'btn btn-success btn-md', 'style' => 'text-transform:uppercase;'])); ?>

            </div>
        </div>
        <?php echo Form::close(); ?>

    </div>
    </div>
    </div>
</div>
<div class="row ads">
    
        
    <div class="container ads text-justify">
        
      

    <h2 class="title text-center">LATEST LISTINGS</h2>
    <h6 class="text-center"> BUY & SELL ANYTHING</h6>
    <?php if(count($boosted_free) > 0): ?>
        <?php if(count($boosted_paid) > 0): ?>
            <?php $__currentLoopData = // Loop through them
                    $boosted_paid; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $boosted_paid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="listings/<?php echo e($boosted_paid->id); ?>" title="">
                <div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
                    <div class="container folio">
                    <div class="panel-default">
                        <div class="panel-body">
                            <div class="bottom-left">
                                <i class="fa fa-eye"></i><span><?php echo e(App\Models\ListingView::where('listings_id', $boosted_paid->id)->count()); ?></span>
                            </div>
                            <div class="bottom-right">
                                <?php echo e(Form::open(array('action' => 'ListingsController@bookmark'))); ?>  
                                <?php echo e(Form::hidden('id', $boosted_paid->id)); ?>

                                <?php echo e(Form::hidden('title', $boosted_paid->title)); ?>

                                <?php echo e(Form::hidden('image', $boosted_paid->image1)); ?>

                                <?php echo e(Form::hidden('type', $boosted_paid->type)); ?>

                                <?php if(auth()->guard()->guest()): ?>
                                <button type="submit" onclick="myFunction(this)" class="fa fa-heart-o" title="Bookmark"></button>
                                <?php else: ?> 
                                <?php if(empty(App\Models\Favorite::where('user_id', '=', auth()->user()->id)->where('listing_id', '=',  $boosted_paid->id)->first())): ?>
                                
                                <button type="submit" onclick="myFunction(this)" class="fa fa-heart-o" title="Bookmark"></button>
                                <?php else: ?> 
                                <button type="submit" onclick="myFunction(this)" class="fa fa-heart" title="Remove Bookmark"></button>
                                <?php endif; ?>
                                <?php endif; ?>
                                <?php echo e(Form::close()); ?>

                            </div>
                            <?php if($boosted_paid->image1 !== 'null'): ?>
                            <img src="<?php echo e(URL::to('img/cover_images/listings/'.$boosted_paid->image1)); ?>" class="img-responsive" alt="">
                            <?php else: ?>
                            <img src="<?php echo e(URL::to('img/AMAS.png')); ?>" class="img-responsive" alt="">
                                
                                
                            <?php endif; ?>
                        </div>
                        <div class="panel-footer">
                            <small class="text-justify"><i class="fa fa-cubes"></i><?php echo Str::words($boosted_paid->title,6); ?></small>
                            <hr>
                            <p class="text-justify">
                                <?php if(!empty($boosted_paid->country)): ?>
                                <i class="fa fa-map-marker"></i><?php echo e($boosted_paid->country); ?>

                                <?php endif; ?>     
                                <?php if(!empty($boosted_paid->price)): ?>
                                | <span>$</span><?php echo e($boosted_paid->price); ?>

                                <?php endif; ?>        
                            </p>
                            
                        </div>
                        <div class="top-left">
                            <span class="btn btn-primary">FEATURED</span>
                        </div>
                    </div>
                    </div>
                </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>         
        <?php if(count($boosted_free) > 0): ?>
            <?php $__currentLoopData = // Loop through them
                    $boosted_free; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $boosted_free): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="listings/<?php echo e($boosted_free->id); ?>" title="">
                <div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
                    <div class="container folio">
                    <div class="panel-default">
                        <div class="panel-body">
                            <div class="bottom-left">
                                <i class="fa fa-eye"></i><span><?php echo e(App\Models\ListingView::where('listings_id', $boosted_free->id)->count()); ?></span>
                            </div>
                            <div class="bottom-right">
                                <?php echo e(Form::open(array('action' => 'ListingsController@bookmark'))); ?>  
                                <?php echo e(Form::hidden('id', $boosted_free->id)); ?>

                                <?php echo e(Form::hidden('title', $boosted_free->title)); ?>

                                <?php echo e(Form::hidden('image', $boosted_free->image1)); ?>

                                <?php echo e(Form::hidden('type', $boosted_free->type)); ?>


                                <?php if(auth()->guard()->guest()): ?>
                                <button type="submit" onclick="myFunction(this)" class="fa fa-heart-o" title="Bookmark"></button>
                                <?php else: ?> 
                                <?php if(empty(App\Models\Favorite::where('user_id', '=', auth()->user()->id)->where('listing_id', '=',  $boosted_free->id)->first())): ?>
                                
                                <button type="submit" onclick="myFunction(this)" class="fa fa-heart-o" title="Bookmark"></button>
                                <?php else: ?> 
                                <button type="submit" onclick="myFunction(this)" class="fa fa-heart" title="Remove Bookmark"></button>
                                
                                <?php endif; ?>
                                <?php endif; ?>
                                <?php echo e(Form::close()); ?>

                            </div>
                            <?php if(!empty($boosted_free->image1)): ?>
                            <img src="<?php echo e(URL::to('img/cover_images/listings/'.$boosted_free->image1)); ?>" class="img-responsive" alt="">
                            <?php else: ?>
                            <img src="<?php echo e(URL::to('img/AMAS.png')); ?>" class="img-responsive" alt="">
                                
                            <?php endif; ?>
                        </div>
                        <div class="panel-footer">
                            <small class="text-justify"><i class="fa fa-cubes"></i><?php echo Str::words($boosted_free->title,6); ?></small>
                            <hr>
                            <p class="text-justify">
                                <?php if(!empty($boosted_free->country)): ?>
                                <i class="fa fa-map-marker"></i><?php echo e($boosted_free->country); ?>

                                <?php endif; ?>     
                                <?php if(!empty($boosted_free->price)): ?>
                                | <span>$</span><?php echo e($boosted_free->price); ?>

                                <?php endif; ?>
                            </p>
                            
                        </div>
                    </div>
                    </div>
                </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>                   
        </div>
    
        <div class="text-center">
            <a href="/alllistings" class="btn btn-success">SEE MORE LISTINGS</a>   
    <?php else: ?>
            <p class="text-center">No Items Yet</p>
    <?php endif; ?>
        </div>
</div>

</div>
<div class="row">
    <?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<script>
            function myFunction(x) {
            x.classList.toggle("fa fa-bookmark");
        }
        var msg = '<?php echo e(Session::get('alert')); ?>';
        var exist = '<?php echo e(Session::has('alert')); ?>';
        if (exist) {
            alert(msg);
        }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Amaslink\resources\views/pages/home.blade.php ENDPATH**/ ?>