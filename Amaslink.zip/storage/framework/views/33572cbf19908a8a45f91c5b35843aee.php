<?php $__env->startSection('page_title'); ?>
<?php echo e(config('app.name')); ?> - Best Free Classified Ads
<?php $__env->stopSection(); ?>
<?php echo $__env->make('inc.css.favorite', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row main">
        <?php echo $__env->make('inc.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<div class="row ads">
    <div class="container text-justify">
        <h2 class="title text-center">YOUR WISH LIST</h2>
        <h6 class="text-center"> BUY & SELL ANYTHING</h6>
        
        <?php if(count($favorites) > 0): ?>
            <?php $__currentLoopData = // Loop through them
                $favorites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $favorite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($favorite->listing_type !== 'paid/auction'): ?>
                <a href="listings/<?php echo e($favorite->listing_id); ?>" class="icon" title="">
                <?php else: ?>
                <a href="auctions/<?php echo e($favorite->listing_id); ?>" class="icon" title="">
                    
                <?php endif; ?>
        <!--<a href="javascript:{}" onclick="document.getElementById('my_form_9').submit();">
            <?php echo e(Form::open(['action' => ['ListingsController@show_f'], 'method' => 'POST', 'id' => 'my_form_9'])); ?>  
            <?php echo e(Form::hidden('id', $favorite->listing_id)); ?>

             <?php echo e(Form::close()); ?>---->
        <div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
            <div class="container folio">
            <div class="panel-default">
                <div class="panel-body">
                    <div class="bottom-left">
                        <i class="fa fa-eye"></i><span><?php echo e(App\Models\ListingView::where('listings_id', $favorite->id)->count()); ?></span>
                    </div>
                    <div class="bottom-right">
                        <?php echo e(Form::open(['action' => 'ListingsController@removebookmark', 'method' => 'POST'])); ?>  
                        <?php echo e(Form::hidden('id', $favorite->id)); ?>

                        <?php echo e(Form::hidden('title', $favorite->title)); ?>

                        <?php echo e(Form::hidden('image', $favorite->image1)); ?>


                        <button type="submit" onclick="myFunction(this)" class="fa fa-heart" title="Bookmark"></button>
                        
                         <?php echo e(Form::close()); ?>

                    </div>
                    <img src="<?php echo e(URL::to('img/cover_images/listings/'.$favorite->image1)); ?>" class="img-responsive" alt="">
                </div>
                <div class="panel-footer">
                    <small class="text-justify"><i class="fa fa-cubes"></i><?php echo Str::words($favorite->title,4); ?></small>
                    <hr>
                    <p class="text-justify"><i class="fa fa-map-marker"></i><?php echo e($favorite->country); ?> | <span>$</span><?php echo e($favorite->price); ?></p>
                    
                </div>
            </div>
            </div>
        </div>
        </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="text-center">
            <div class="d-flex justify-content-center" style="padding-bottom:10px">
            
                <?php if($favorites->currentPage() > 1): ?>
                <a href="<?php echo e($favorites->previousPageUrl()); ?>" class="btn btn-primary pagination">Previous</a>
                <?php endif; ?>
                
                <?php if($favorites->hasMorePages()): ?>
                <a href="<?php echo e($favorites->nextPageUrl()); ?>" class="btn btn-primary pagination">Next</a>
                <?php endif; ?>
            </div>
        </div>
        <?php else: ?>
            <p class="text-center">Nothing to display here.</p>
    <?php endif; ?>  
    </div>
    
</div>
<div class="row">
    <?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<script>
            function myFunction(x) {
            x.classList.toggle("fa fa-bookmark");
        }
        var msg = '<?php echo e(Session::get('alert')); ?>';
        var exist = '<?php echo e(Session::has('alert')); ?>';
        if (exist) {
            alert(msg);
        }
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainone', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Amaslink\resources\views/pages/favorite.blade.php ENDPATH**/ ?>