
<style>

    #main {
      transition: margin-left .5s;
      padding: 16px;
    }
    
    a.btn-primary{
          color: #b20000;
            background: transparent;
            margin-bottom: 0;
            font-size: 15px;
    
        }
        .btn.btn-primary.btn-sm.edit{
          color: #b20000;
            background: transparent;
            margin-bottom: 0;
            font-size: 10px;
            padding: 0;
            border: none;
    
        }
        a.btn.btn-info.btn-sm{
          padding: 0;
          background: transparent;
          color: #b20000;
          border: none;
          margin-left: 20px;
          font-size: 15px;
        }
        a.btn-primary:hover,
        a.btn-info.pull-left:hover{
            background:#b20000;
            color: seashell;
        }
        a.btn-info.pull-left{
            margin-top:20px;
            margin-bottom:300px;
            margin-left: 20px;
            color: #b20000;
            background: transparent;
            margin-bottom: 0;
            font-size: 15px;
            border: 1px solid #b20000;
    
        }
        a.pull-right{
            margin-top:20px;
            padding-top: 0;
        }
    input.btn.btn-default{
    background: transparent;
    border-radius: 0;
    font-size: 13px;
    border: 1px solid #b20000;
    color: #b20000;
    margin-bottom: 10px;
    }
    .btn.btn-danger{
    background: transparent;
    border-radius: 0;
    font-size: 9px;
    border: 1px solid #b20000;
    color: #b20000;
    margin-bottom: 0;
    }
        .panel-default{
        border-radius: 0;
        box-shadow: 0 5px 5px 0 rgba(0, 0, 0, 0.2);
        border: none;
        }
        .panel-default.ad{
        border-radius: 0;
        margin-top: 20px;
        border: none;
        box-shadow: 0 5px 5px 0 rgba(0, 0, 0, 0.2);
        }
        .panel-default.ad a{
        text-decoration: wavy;
        color: #b20000;
        }
        .panel-default.ad .panel-heading{
        padding-top: 30px;
        padding-bottom: 30px;
        }
        .panel-body p,
        .panel-body span{
        font-size: 13px;
        }
        .panel-body a{
        text-decoration: wavy;
        color: #b20000;
        }
        .panel-heading h3,
        .panel-heading span{
        color: #b20000;
        }
    a.btn.btn-default{
    background: transparent;
    border-radius: 0;
    font-size: 13px;
    border: 1px solid #b20000;
    color: #b20000;
    margin-bottom: 10px;
    }
            li{
                list-style: square;
                color: #b20000;
            }
    
            .col-sm-3 li a,
            a{
    text-decoration: none;
    color: #b20000;
    }
            .col-sm-3 li a:hover,
            a:hover{
    text-decoration: none;
    color: #b20000;
    }
    .row.forum{
        padding-top: 80px;
    }
        @media only screen and (max-width: 768px) {
        
    }
    </style><?php /**PATH E:\xampp\htdocs\Amaslink\resources\views/inc/css/announcement.blade.php ENDPATH**/ ?>