
<?php $__env->startSection('page_title'); ?>
<?php echo e(config('app.name')); ?> - Best Free Classified Ads | Categories
<?php $__env->stopSection(); ?>
<?php echo $__env->make('inc.css.category', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('inc.navother', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="row bl">
    <div class="container text-center">
        <h2 class="text-center title">AVAILABLE CATEGORIES</h2>
        <div class="col-sm-2">
            <a href="javascript:{}" onclick="document.getElementById('my_form_1').submit();">
                <div class="panel">
                    <img src="img/brand.png" alt="brand category" class="img-responsive">
                </div>
                <?php echo Form::open(['action' => 'PagesController@category', 'method' => 'GET', 'id' => 'my_form_1']) /** The action should be the block of code in the store function in PostsController
                **/; ?>

                <p>
                     <?php echo e(Form::hidden('category', 'brand')); ?>

                     <?php echo e(Form::submit('BRANDS', ['class' => 'btn btn-success', 'style' => 'text-transform:uppercase;'])); ?>

                    
                    <br>
                    (<?php echo e(App\Models\Listings::where('category', 'BRANDS')->where('status', 'approved')->count()); ?>)
                </p>
                <?php echo Form::close(); ?>

            </a>
        </div>
        <div class="col-sm-2">
            <a href="javascript:{}" onclick="document.getElementById('my_form_2').submit();">
                <div class="panel">
                    <img src="img/creativity.jpg" alt="creativity category" class="img-responsive">
                </div>
                <?php echo Form::open(['action' => 'PagesController@category', 'method' => 'GET', 'id' => 'my_form_2']) /** The action should be the block of code in the store function in PostsController
                **/; ?>

                <p>
                     <?php echo e(Form::hidden('category', 'CREATIVITY')); ?>

                     <?php echo e(Form::submit('CREATIVITY', ['class' => 'btn btn-success', 'style' => 'text-transform:uppercase;'])); ?>

                    
                    <br>
                    (<?php echo e(App\Models\Listings::where('category', 'CREATIVITY')->where('status', 'approved')->count()); ?>)
                </p>
                <?php echo Form::close(); ?>

          </a>
        </div>
        <div class="col-sm-2">
            <a href="javascript:{}" onclick="document.getElementById('my_form_3').submit();">
            <div class="panel">
                <img src="img/sport.png" alt="brand category" class="img-responsive">
            </div>
            <?php echo Form::open(['action' => 'PagesController@category', 'method' => 'GET', 'id' => 'my_form_3']) /** The action should be the block of code in the store function in PostsController
            **/; ?>

            <p>
                 <?php echo e(Form::hidden('category', 'SPORT')); ?>

                 <?php echo e(Form::submit('SPORT', ['class' => 'btn btn-success', 'style' => 'text-transform:uppercase;'])); ?>

                
                <br>
                (<?php echo e(App\Models\Listings::where('category', 'SPORT')->where('status', 'approved')->count()); ?>)
            </p>
            <?php echo Form::close(); ?>

            </a>
        </div>
        <div class="col-sm-2">
            <a href="javascript:{}" onclick="document.getElementById('my_form_4').submit();">
            <div class="panel">
                <img src="img/currency.png" alt="brand category" class="img-responsive">
            </div>
            <?php echo Form::open(['action' => 'PagesController@category', 'method' => 'GET', 'id' => 'my_form_4']) /** The action should be the block of code in the store function in PostsController
            **/; ?>

            <p>
                 <?php echo e(Form::hidden('category', 'CURRENCY TRADING')); ?>

                 <?php echo e(Form::submit('CURRENCY TRADING', ['class' => 'btn btn-success', 'style' => 'text-transform:uppercase;'])); ?>

                
                <br>
                (<?php echo e(App\Models\Listings::where('category', 'CURRENCY TRADING')->where('status', 'approved')->count()); ?>)
            </p>
            <?php echo Form::close(); ?>

             </a>
        </div>
        <div class="col-sm-2">
            <a href="javascript:{}" onclick="document.getElementById('my_form_5').submit();">
            <div class="panel">
                <img src="img/mineral.png" alt="brand category" class="img-responsive">
            </div>
            <?php echo Form::open(['action' => 'PagesController@category', 'method' => 'GET', 'id' => 'my_form_5']) /** The action should be the block of code in the store function in PostsController
            **/; ?>

            <p>
                 <?php echo e(Form::hidden('category', 'MINERAL, CRUDE OIL')); ?>

                 <?php echo e(Form::submit('MINERAL/CRUDE OIL', ['class' => 'btn btn-success', 'style' => 'text-transform:uppercase;'])); ?>

                
                <br>
                (<?php echo e(App\Models\Listings::where('category', 'MINERAL, CRUDE OIL')->where('status', 'approved')->count()); ?>)
            </p>
            <?php echo Form::close(); ?>

            </a>
        </div>
        <div class="col-sm-2">
            <a href="javascript:{}" onclick="document.getElementById('my_form_6').submit();">
            <div class="panel">
                <img src="img/kid.png" alt="brand category" class="img-responsive">
            </div>
            <?php echo Form::open(['action' => 'PagesController@category', 'method' => 'GET', 'id' => 'my_form_6']) /** The action should be the block of code in the store function in PostsController
            **/; ?>

            <p>
                 <?php echo e(Form::hidden('category', 'KIDS AND BABIES')); ?>

                 <?php echo e(Form::submit('KIDS AND BABIES', ['class' => 'btn btn-success', 'style' => 'text-transform:uppercase;'])); ?>

                
                <br>
                (<?php echo e(App\Models\Listings::where('category', 'KIDS AND BABIES')->where('status', 'approved')->count()); ?>)
            </p>
            <?php echo Form::close(); ?>

            </a>
        </div>
        <div class="col-sm-2">
            <a href="javascript:{}" onclick="document.getElementById('my_form_7').submit();">
            <div class="panel">
                <img src="img/sale.png" alt="brand category" class="img-responsive">
            </div>
            <?php echo Form::open(['action' => 'PagesController@category', 'method' => 'GET', 'id' => 'my_form_7']) /** The action should be the block of code in the store function in PostsController
            **/; ?>

            <p>
                 <?php echo e(Form::hidden('category', 'BUSINESS SALES')); ?>

                 <?php echo e(Form::submit('BUSINESS SALES', ['class' => 'btn btn-success', 'style' => 'text-transform:uppercase;'])); ?>

                
                <br>
                (<?php echo e(App\Models\Listings::where('category', 'BUSINESS SALES')->where('status', 'approved')->count()); ?>)
            </p>
            <?php echo Form::close(); ?>

            </a>
        </div>
        <div class="col-sm-2">
            <a href="javascript:{}" onclick="document.getElementById('my_form_8').submit();">
            <div class="panel">
                <img src="img/mobi.png" alt="brand category" class="img-responsive">
            </div>
            <?php echo Form::open(['action' => 'PagesController@category', 'method' => 'GET', 'id' => 'my_form_8']) /** The action should be the block of code in the store function in PostsController
            **/; ?>

            <p>
                 <?php echo e(Form::hidden('category', 'MOBILE,ELECTRONICS')); ?>

                 <?php echo e(Form::submit('MOBILE/ELECTRONICS', ['class' => 'btn btn-success', 'style' => 'text-transform:uppercase;'])); ?>

                
                <br>
                (<?php echo e(App\Models\Listings::where('category', 'MOBILE,ELECTRONICS')->where('status', 'approved')->count()); ?>)
            </p>
            <?php echo Form::close(); ?>

            </a>
        </div>
        <div class="col-sm-2">
            <a href="javascript:{}" onclick="document.getElementById('my_form_9').submit();">
            <div class="panel">
                <img src="img/job.png" alt="brand category" class="img-responsive">
            </div>
            <?php echo Form::open(['action' => 'PagesController@category', 'method' => 'GET', 'id' => 'my_form_9']) /** The action should be the block of code in the store function in PostsController
            **/; ?>

            <p>
                 <?php echo e(Form::hidden('category', 'SEEKING JOBS/CV')); ?>

                 <?php echo e(Form::submit('SEEKING JOBS/CV', ['class' => 'btn btn-success', 'style' => 'text-transform:uppercase;'])); ?>

                
                <br>
                (<?php echo e(App\Models\Listings::where('category', 'Jobs')->where('category', 'SEEKING JOBS/CV')->where('status', 'approved')->count()); ?>)
            </p>
            <?php echo Form::close(); ?>

            </a>
        </div>
        <div class="col-sm-2">
            <a href="javascript:{}" onclick="document.getElementById('my_form_26').submit();">
            <div class="panel">
                <img src="img/jobb.png" alt="brand category" class="img-responsive">
            </div>
            <?php echo Form::open(['action' => 'PagesController@category', 'method' => 'GET', 'id' => 'my_form_26']) /** The action should be the block of code in the store function in PostsController
            **/; ?>

            <p>
                 <?php echo e(Form::hidden('category', 'JOBS')); ?>

                 <?php echo e(Form::submit('JOBS', ['class' => 'btn btn-success', 'style' => 'text-transform:uppercase;'])); ?>

                
                <br>
                (<?php echo e(App\Models\Listings::where('category', 'Jobs')->where('category', 'JOBS')->where('status', 'approved')->count()); ?>)
            </p>
            <?php echo Form::close(); ?>

            </a>
        </div>
        <div class="col-sm-2">
            <a href="javascript:{}" onclick="document.getElementById('my_form_10').submit();">
            <div class="panel">
                <img src="img/real.png" alt="brand category" class="img-responsive">
            </div>
            <?php echo Form::open(['action' => 'PagesController@category', 'method' => 'GET', 'id' => 'my_form_10']) /** The action should be the block of code in the store function in PostsController
            **/; ?>

            <p>
                 <?php echo e(Form::hidden('category', 'REAL ESTATE, LANDS')); ?>

                 <?php echo e(Form::submit('REAL ESTATE/LANDS', ['class' => 'btn btn-success', 'style' => 'text-transform:uppercase;'])); ?>

                
                <br>
                (<?php echo e(App\Models\Listings::where('category', 'REAL ESTATE, LANDS')->where('status', 'approved')->count()); ?>)
            </p>
            <?php echo Form::close(); ?>

            </a>
        </div>
        <div class="col-sm-2">
            <a href="javascript:{}" onclick="document.getElementById('my_form_11').submit();">
            <div class="panel">
                <img src="img/auto.png" alt="brand category" class="img-responsive">
            </div>
            <?php echo Form::open(['action' => 'PagesController@category', 'method' => 'GET', 'id' => 'my_form_11']) /** The action should be the block of code in the store function in PostsController
            **/; ?>

            <p>
                 <?php echo e(Form::hidden('category', 'AUTOMOBILES')); ?>

                 <?php echo e(Form::submit('AUTOMOBILES', ['class' => 'btn btn-success', 'style' => 'text-transform:uppercase;'])); ?>

                
                <br>
                (<?php echo e(App\Models\Listings::where('category', 'AUTOMOBILES')->where('status', 'approved')->count()); ?>)
            </p>
            <?php echo Form::close(); ?>

            </a>
        </div>
        
        <div class="col-sm-2">
            <a href="javascript:{}" onclick="document.getElementById('my_form_12').submit();">
                <div class="panel">
                    <img src="img/tone.svg" alt="brand category" class="img-responsive">
                </div>
                <?php echo Form::open(['action' => 'PagesController@category', 'method' => 'GET', 'id' => 'my_form_12']) /** The action should be the block of code in the store function in PostsController
                **/; ?>

                <p>
                     <?php echo e(Form::hidden('category', 'Precious Stone')); ?>

                     <?php echo e(Form::submit('Precious Stone', ['class' => 'btn btn-success', 'style' => 'text-transform:uppercase;'])); ?>

                    
                    <br>
                    (<?php echo e(App\Models\Listings::where('category', 'Precious Stone')->where('status', 'approved')->count()); ?>)
                </p>
                <?php echo Form::close(); ?>

            </a>
        </div>
        <div class="col-sm-2">
            <a href="javascript:{}" onclick="document.getElementById('my_form_13').submit();">
                <div class="panel">
                    <img src="img/movie.png" alt="creativity category" class="img-responsive">
                </div>
                <?php echo Form::open(['action' => 'PagesController@category', 'method' => 'GET', 'id' => 'my_form_13']) /** The action should be the block of code in the store function in PostsController
                **/; ?>

                <p>
                     <?php echo e(Form::hidden('category', 'Movies And Scripts')); ?>

                     <?php echo e(Form::submit('Movies And Scripts', ['class' => 'btn btn-success', 'style' => 'text-transform:uppercase;'])); ?>

                    
                    <br>
                    (<?php echo e(App\Models\Listings::where('category', 'Movies And Scripts')->where('status', 'approved')->count()); ?>)
                </p>
                <?php echo Form::close(); ?>

          </a>
        </div>
        <div class="col-sm-2">
            <a href="javascript:{}" onclick="document.getElementById('my_form_14').submit();">
            <div class="panel">
                <img src="img/schoo.png" alt="brand category" class="img-responsive">
            </div>
            <?php echo Form::open(['action' => 'PagesController@category', 'method' => 'GET', 'id' => 'my_form_14']) /** The action should be the block of code in the store function in PostsController
            **/; ?>

            <p>
                 <?php echo e(Form::hidden('category', 'Education')); ?>

                 <?php echo e(Form::submit('Education', ['class' => 'btn btn-success', 'style' => 'text-transform:uppercase;'])); ?>

                
                <br>
                (<?php echo e(App\Models\Listings::where('category', 'Education')->where('status', 'approved')->count()); ?>)
            </p>
            <?php echo Form::close(); ?>

            </a>
        </div>
        <div class="col-sm-2">
            <a href="javascript:{}" onclick="document.getElementById('my_form_15').submit();">
                <div class="panel">
                    <img src="img/schoo.png" alt="brand category" class="img-responsive">
                </div>
                <?php echo Form::open(['action' => 'PagesController@category', 'method' => 'GET', 'id' => 'my_form_15']) /** The action should be the block of code in the store function in PostsController
                **/; ?>

                <p>
                     <?php echo e(Form::hidden('category', 'Thesis Help')); ?>

                     <?php echo e(Form::submit('Thesis Help', ['class' => 'btn btn-success', 'style' => 'text-transform:uppercase;'])); ?>

                    
                    <br>
                    (<?php echo e(App\Models\Listings::where('category', 'Thesis Help')->where('status', 'approved')->count()); ?>)
                </p>
                <?php echo Form::close(); ?>

            </a>
        </div>
        <div class="col-sm-2">
            <a href="javascript:{}" onclick="document.getElementById('my_form_16').submit();">
                <div class="panel">
                    <img src="img/trve.png" alt="creativity category" class="img-responsive">
                </div>
                <?php echo Form::open(['action' => 'PagesController@category', 'method' => 'GET', 'id' => 'my_form_16']) /** The action should be the block of code in the store function in PostsController
                **/; ?>

                <p>
                     <?php echo e(Form::hidden('category', 'Travel')); ?>

                     <?php echo e(Form::submit('Travel', ['class' => 'btn btn-success', 'style' => 'text-transform:uppercase;'])); ?>

                    
                    <br>
                    (<?php echo e(App\Models\Listings::where('category', 'Travel')->where('status', 'approved')->count()); ?>)
                </p>
                <?php echo Form::close(); ?>

          </a>
        </div>
        <div class="col-sm-2">
            <a href="javascript:{}" onclick="document.getElementById('my_form_17').submit();">
            <div class="panel">
                <img src="img/fhion.png" alt="brand category" class="img-responsive">
            </div>
            <?php echo Form::open(['action' => 'PagesController@category', 'method' => 'GET', 'id' => 'my_form_17']) /** The action should be the block of code in the store function in PostsController
            **/; ?>

            <p>
                 <?php echo e(Form::hidden('category', 'Fashion')); ?>

                 <?php echo e(Form::submit('Fashion', ['class' => 'btn btn-success', 'style' => 'text-transform:uppercase;'])); ?>

                
                <br>
                (<?php echo e(App\Models\Listings::where('category', 'Fashion')->where('status', 'approved')->count()); ?>)
            </p>
            <?php echo Form::close(); ?>

            </a>
        </div>
        <div class="col-sm-2">
            <a href="javascript:{}" onclick="document.getElementById('my_form_18').submit();">
            <div class="panel">
                <img src="img/nim.png" alt="brand category" class="img-responsive">
            </div>
            <?php echo Form::open(['action' => 'PagesController@category', 'method' => 'GET', 'id' => 'my_form_18']) /** The action should be the block of code in the store function in PostsController
            **/; ?>

            <p>
                 <?php echo e(Form::hidden('category', 'Animal')); ?>

                 <?php echo e(Form::submit('Animal', ['class' => 'btn btn-success', 'style' => 'text-transform:uppercase;'])); ?>

                
                <br>
                (<?php echo e(App\Models\Listings::where('category', 'Animal')->where('status', 'approved')->count()); ?>)
            </p>
            <?php echo Form::close(); ?>

            </a>
        </div>
        <div class="col-sm-2">
            <a href="javascript:{}" onclick="document.getElementById('my_form_19').submit();">
            <div class="panel">
                <img src="img/event.png" alt="brand category" class="img-responsive">
            </div>
            <?php echo Form::open(['action' => 'PagesController@category', 'method' => 'GET', 'id' => 'my_form_19']) /** The action should be the block of code in the store function in PostsController
            **/; ?>

            <p>
                 <?php echo e(Form::hidden('category', 'Events')); ?>

                 <?php echo e(Form::submit('Events', ['class' => 'btn btn-success', 'style' => 'text-transform:uppercase;'])); ?>

                
                <br>
                (<?php echo e(App\Models\Listings::where('category', 'Events')->where('status', 'approved')->count()); ?>)
            </p>
            <?php echo Form::close(); ?>

            </a>
        </div>
        <div class="col-sm-2">
            <a href="javascript:{}" onclick="document.getElementById('my_form_20').submit();">
            <div class="panel">
                <img src="img/heth.png" alt="brand category" class="img-responsive">
            </div>
            <?php echo Form::open(['action' => 'PagesController@category', 'method' => 'GET', 'id' => 'my_form_20']) /** The action should be the block of code in the store function in PostsController
            **/; ?>

            <p>
                 <?php echo e(Form::hidden('category', 'Health')); ?>

                 <?php echo e(Form::submit('Health', ['class' => 'btn btn-success', 'style' => 'text-transform:uppercase;'])); ?>

                
                <br>
                (<?php echo e(App\Models\Listings::where('category', 'Health')->where('status', 'approved')->count()); ?>)
            </p>
            <?php echo Form::close(); ?>

            </a>
        </div>
        <div class="col-sm-2">
            <a href="javascript:{}" onclick="document.getElementById('my_form_21').submit();">
            <div class="panel">
                <img src="img/home.png" alt="brand category" class="img-responsive">
            </div>
            <?php echo Form::open(['action' => 'PagesController@category', 'method' => 'GET', 'id' => 'my_form_21']) /** The action should be the block of code in the store function in PostsController
            **/; ?>

            <p>
                 <?php echo e(Form::hidden('category', 'Home & Lifestyle')); ?>

                 <?php echo e(Form::submit('Home & Lifestyle', ['class' => 'btn btn-success', 'style' => 'text-transform:uppercase;'])); ?>

                
                <br>
                (<?php echo e(App\Models\Listings::where('category', 'Home & Lifestyle')->where('status', 'approved')->count()); ?>)
            </p>
            <?php echo Form::close(); ?>

            </a>
        </div>
        <div class="col-sm-2">
            <a href="javascript:{}" onclick="document.getElementById('my_form_22').submit();">
            <div class="panel">
                <img src="img/ife.png" alt="brand category" class="img-responsive">
            </div>
            <?php echo Form::open(['action' => 'PagesController@category', 'method' => 'GET', 'id' => 'my_form_22']) /** The action should be the block of code in the store function in PostsController
            **/; ?>

            <p>
                 <?php echo e(Form::hidden('category', 'Matrimonials')); ?>

                 <?php echo e(Form::submit('Matrimonials', ['class' => 'btn btn-success', 'style' => 'text-transform:uppercase;'])); ?>

                
                <br>
                (<?php echo e(App\Models\Listings::where('category', 'Matrimonials')->where('status', 'approved')->count()); ?>)
            </p>
            <?php echo Form::close(); ?>

            </a>
        </div>
        <div class="col-sm-2">
            <a href="javascript:{}" onclick="document.getElementById('my_form_23').submit();">
            <div class="panel">
                <img src="img/auto.png" alt="brand category" class="img-responsive">
            </div>
            <?php echo Form::open(['action' => 'PagesController@category', 'method' => 'GET', 'id' => 'my_form_23']) /** The action should be the block of code in the store function in PostsController
            **/; ?>

            <p>
                 <?php echo e(Form::hidden('category', 'Classic Cars')); ?>

                 <?php echo e(Form::submit('Classic Cars', ['class' => 'btn btn-success', 'style' => 'text-transform:uppercase;'])); ?>

                
                <br>
                (<?php echo e(App\Models\Listings::where('category', 'Classic Cars')->where('status', 'approved')->count()); ?>)
            </p>
            <?php echo Form::close(); ?>

            </a>
        </div>
        <div class="col-sm-2">
            <a href="javascript:{}" onclick="document.getElementById('my_form_24').submit();">
            <div class="panel">
                <img src="img/kid.png" alt="brand category" class="img-responsive">
            </div>
            <?php echo Form::open(['action' => 'PagesController@category', 'method' => 'GET', 'id' => 'my_form_24']) /** The action should be the block of code in the store function in PostsController
            **/; ?>

            <p>
                 <?php echo e(Form::hidden('category', 'Baby Toys')); ?>

                 <?php echo e(Form::submit('Baby Toys', ['class' => 'btn btn-success', 'style' => 'text-transform:uppercase;'])); ?>

                
                <br>
                (<?php echo e(App\Models\Listings::where('category', 'Baby Toys')->where('status', 'approved')->count()); ?>)
            </p>
            <?php echo Form::close(); ?>

            </a>
        </div>

        <div class="col-sm-2">
            <a href="javascript:{}" onclick="document.getElementById('my_form_25').submit();">
            <div class="panel">
                <img src="img/service.png" alt="brand category" class="img-responsive">
            </div>
            <?php echo Form::open(['action' => 'PagesController@category', 'method' => 'GET', 'id' => 'my_form_25']) /** The action should be the block of code in the store function in PostsController
            **/; ?>

            <p>
                 <?php echo e(Form::hidden('category', 'Services')); ?>

                 <?php echo e(Form::submit('Services', ['class' => 'btn btn-success', 'style' => 'text-transform:uppercase;'])); ?>

                
                <br>
                (<?php echo e(App\Models\Listings::where('category', 'Services')->where('status', 'approved')->count()); ?>)
            </p>
            <?php echo Form::close(); ?>

            </a>
        </div>

    </div>
</div>
<?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainone', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Amaslink\resources\views/pages/category.blade.php ENDPATH**/ ?>