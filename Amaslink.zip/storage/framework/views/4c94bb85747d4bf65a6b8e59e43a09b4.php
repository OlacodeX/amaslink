
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="author" content="OlacodeX" />

<?php $__env->startSection('page_title'); ?>
<?php echo e(config('app.name')); ?> | Blog
<?php $__env->stopSection(); ?>
<?php echo $__env->make('inc.css.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('inc.navother', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="row">
        <div class="jumbotron text-center" style="background:linear-gradient(rgba(180, 4, 4, 0.76),rgba(8, 8, 8, 0.863)),url(<?php echo e('img/cover_images/'.$mostRs->cover_image); ?>) no-repeat; background-position: center; background-size:cover;">
     
            <a href="<?php echo e(route('blog.show', $mostRs->slug)); ?>" style="text-decoration: none;">
            <h2 class="titlem"><?php echo e($mostRs->title); ?></h2>
            </a>    
            <p>
                <?php echo Str::words( $mostRs->body,25); ?>

            </p>
            <small><?php echo Str::words( $mostRs->created_at,1); ?> / <?php echo e($mostRs->author); ?> / <?php echo e($mostRs->category); ?></small><br>
            <a href="<?php echo e(route('blog.show', $mostRs->slug)); ?>" class="btn btn-info btn-md">Read More</a>
        </div>
           
        </div>
        <div class="container">
        
        <div class="col-sm-3 img1">
           <a href=""><img src="img/add.png" alt="" class="img-responsive"></a> 
            <div class="panel-group">
                <div class="panel panel-default ad">
                    <a data-toggle="collapse" href="#collapse1">
                    <div class="panel-heading">
                        <h4 class="panel-title text-center">
                        Safety Tips
                        </h4>
                    </div>
                    </a>
                  <div id="collapse1" class="panel-collapse collapse in">
                    <div class="panel-body">
                        <ul>
                            <li>Meet seller at a safe location</li>
                            <li>Check the item before you buy</li>
                            <li>Pay only after collecting item</li>
                        </ul>
                    </div>
                  </div>
                </div>
            </div>
        </div>
        <div class="col-sm-6 img2">
            
    <?php if(
        //if there is data in the db
    count($posts) > 0
    ): ?>
        <?php $__currentLoopData = // Loop through them
            $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php $__env->startSection('page_description'); ?>
<?php echo e(config('app.name')); ?>,<?php echo e(config('app.name')); ?> blog, <?php echo e($post->title); ?>

<?php $__env->stopSection(); ?>
            
<a href="<?php echo e(route('blog.show', $post->slug)); ?>" style="text-decoration: none;">
    <img src="<?php echo e(URL::to('img/cover_images/'.$post->cover_image)); ?>" class="img-responsive" alt="">

</a>
<a href="<?php echo e(route('blog.show', $post->slug)); ?>" style="text-decoration: none;">
<h2 class="title"><?php echo e($post->title); ?></h2>
</a>
<small><?php echo Str::words( $post->created_at,1); ?> / <?php echo e($post->author); ?> / <?php echo e($post->category); ?></small><br>
            <p>
                <?php echo Str::words( $post->body,25); ?>

                
</p>
    <a href="<?php echo e(route('blog.show', $post->slug)); ?>" class="btn btn-info btn-md pull-left">Read More</a><br>
    <div class="top-left">
        <span class="btn btn-primary"><i class="fa fa-eye"></i><?php echo e(App\Models\PostView::where('posts_id', $post->id)->count()); ?></span>
                
    </div><br><br><br>
       <!---<a href="chat/create">me</a>--->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    <div class="col-md-12" style="text-align:right;">
            <!-----The pagination link----->
            <?php echo e($posts->links()); ?>

    </div>
        <?php else: ?>
        <p>No post found</p>
            
        <?php endif; ?>
        </div>
        <div class="col-sm-3 last">
            <h3 class="title">Categories</h3>
            <hr class="hrr">
            
            <?php echo Form::open(['action' => 'PagesController@category', 'method' => 'GET', 'id' => 'my_form_1']) /** The action should be the block of code in the store function in PostsController
            **/; ?>

                 <?php echo e(Form::hidden('category', 'CURRENCY TRADING')); ?>

                 <?php echo e(Form::submit('CURRENCY TRADING', ['class' => 'btn btn-default'])); ?>

                
            <?php echo Form::close(); ?>

            <?php echo Form::open(['action' => 'PagesController@category', 'method' => 'GET', 'id' => 'my_form_2']) /** The action should be the block of code in the store function in PostsController
            **/; ?>

                 <?php echo e(Form::hidden('category', 'MINERAL, CRUDE OIL')); ?>

                 <?php echo e(Form::submit('MINERAL/CRUDE OIL', ['class' => 'btn btn-default', 'style' => 'text-transform:uppercase;'])); ?>

                
               
                
           
            <?php echo Form::close(); ?>

            <?php echo Form::open(['action' => 'PagesController@category', 'method' => 'GET', 'id' => 'my_form_4']) /** The action should be the block of code in the store function in PostsController
            **/; ?>

                 <?php echo e(Form::hidden('category', 'BUSINESS SALES')); ?>

                 <?php echo e(Form::submit('BUSINESS SALES', ['class' => 'btn btn-default'])); ?>

                
            <?php echo Form::close(); ?>

            <?php echo Form::open(['action' => 'PagesController@category', 'method' => 'GET', 'id' => 'my_form_4']) /** The action should be the block of code in the store function in PostsController
            **/; ?>

                 <?php echo e(Form::hidden('category', 'MOBILE,ELECTRONICS')); ?>

                 <?php echo e(Form::submit('MOBILE,ELECTRONICS', ['class' => 'btn btn-default'])); ?>

                
            <?php echo Form::close(); ?>

            <?php echo Form::open(['action' => 'PagesController@category', 'method' => 'GET', 'id' => 'my_form_4']) /** The action should be the block of code in the store function in PostsController
            **/; ?>

                 <?php echo e(Form::hidden('category', 'JOBS')); ?>

                 <?php echo e(Form::submit('JOBS', ['class' => 'btn btn-default'])); ?>

                
            <?php echo Form::close(); ?>

            <?php echo Form::open(['action' => 'PagesController@category', 'method' => 'GET', 'id' => 'my_form_4']) /** The action should be the block of code in the store function in PostsController
            **/; ?>

                 <?php echo e(Form::hidden('category', 'REAL ESTATE, LANDS')); ?>

                 <?php echo e(Form::submit('REAL ESTATE, LANDS', ['class' => 'btn btn-default'])); ?>

                
            <?php echo Form::close(); ?>

            <?php echo Form::open(['action' => 'PagesController@category', 'method' => 'GET', 'id' => 'my_form_4']) /** The action should be the block of code in the store function in PostsController
            **/; ?>

                 <?php echo e(Form::hidden('category', 'AUTOMOBILES')); ?>

                 <?php echo e(Form::submit('AUTOMOBILES', ['class' => 'btn btn-default'])); ?>

                
            <?php echo Form::close(); ?>

            <?php echo Form::open(['action' => 'PagesController@category', 'method' => 'GET', 'id' => 'my_form_4']) /** The action should be the block of code in the store function in PostsController
            **/; ?>

                 <?php echo e(Form::hidden('category', 'KIDS AND BABIES')); ?>

                 <?php echo e(Form::submit('KIDS AND BABIES', ['class' => 'btn btn-default'])); ?>

                
            <?php echo Form::close(); ?>

            <?php echo Form::open(['action' => 'PagesController@category', 'method' => 'GET', 'id' => 'my_form_4']) /** The action should be the block of code in the store function in PostsController
            **/; ?>

                 <?php echo e(Form::hidden('category', 'SPORT')); ?>

                 <?php echo e(Form::submit('SPORT', ['class' => 'btn btn-default'])); ?>

                
            <?php echo Form::close(); ?>

            <h3 class="title">Tags</h3>
            <hr class="hrr">
            <a href="./Posts" class="btn btn-default">Blog</a>
            <a href="./communities" class="btn btn-default">Forum</a>
            <a href="./alllistings" class="btn btn-default">Ad Listings</a>
            <a href="./contact" class="btn btn-default">Talk To Us</a>
        </div>
    </div>
    </div>

    <div class="row footer">
    <?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script> 

    <script>
        // When the user scrolls down 20px from the top of the document, show the button
        window.onscroll = function() {scrollFunction()};
        
        function scrollFunction() {
            if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
            document.getElementById("myBtn").style.display = "block";
            } else {
            document.getElementById("myBtn").style.display = "none";
            }
        }
        
        // When the user clicks on the button, scroll to the top of the document
        function topFunction() {
            document.body.scrollTop = 0;
            document.documentElement.scrollTop = 0;
        }
        function myFunction(x) {
            x.classList.toggle("fa fa-bookmark");
        }
        var msg = '<?php echo e(Session::get('alert')); ?>';
        var exist = '<?php echo e(Session::has('alert')); ?>';
        if (exist) {
            alert(msg);
        }
        </script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainone', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Amaslink\resources\views/Posts/index.blade.php ENDPATH**/ ?>