<style>  
#navbar1 {
    overflow: hidden;
    background: transparent;
  }
      .sticky1 {
                position: fixed;
                top: 100px;
                bottom: 100px;
                z-index: 99;
                color: #b20000;
                margin-right: 0px;
                margin-left: 500px;
              } 
              h5.ct{
                color: #b20000;
                margin-left: 100px;
              } 
      div.row.main{
                  background:linear-gradient(rgba(253, 253, 253, 0.404),rgba(230, 227, 227, 0.514)), url('img/bggg3.jpeg') no-repeat;
                  background-size: cover;
                  background-position:center;
                  background-attachment:fixed;
                  padding-bottom: 50px;
      }
      div.jumbotron{
          padding-top: 50px;
          background: transparent;
          color: #0c0c0c;
      }
      div.jumbotron h1{
          color: #b20000;
          font-weight: bold;
      }
      div.jumbotron h3{
          color: #b2000095;
          font-weight: bold;
      }
      div.jumbotron .container{
          width: 60%;
      }
      div.jumbotron .container p{
          font-size: 15px;
          line-height: 1.8em;
      }
      div.jumbotron .col-sm-5 input{
          margin: 0;
      }
      div.jumbotron form input.btn.btn-success.btn-md{
          background: #b20000;
          border: none;
          border-radius: 5px;
          padding: 2px 30px;
          font-size: 20px;
          color: #f1f1f1;
      }
      div.jumbotron form input.btn.btn-success.btn-md:hover{
        
          color: #B2000093;
          border: 1px solid #B20000;
          background: transparent;
      }
  
      .container-fluid.form{
              background-color:transparent;
          }
      .row.bl img{
          margin-bottom: 10px;
          width: 50px;
          margin-left: 30px;
      }
      .row.bl div.panel.add img{
          height: 160px;
          width: 350px;
      }
      .row.bl div.panel{
          
          padding: 40px 20px;
          border-radius: 0;
      }
      .row.bl div.panel.add{
          
          padding:0;
          box-shadow: none;
          border-radius: 0;
      }
      
  div.col-sm-2{
      display:none;
  }
  #loadMoree {
      transition: all 600ms ease-in-out;
      -webkit-transition: all 600ms ease-in-out;
      -moz-transition: all 600ms ease-in-out;
      -o-transition: all 600ms ease-in-out;
      
  }
      .overlay1 div.col-sm-2 p{
          font-size: 8px;
          font-weight: bold;
          color: #f1f1f1;
      }
      .overlay1 .btn.btn-success{
          background: #f1f1f1;
          color: #b20000;
      }
      .overlay-content div.col-sm-2 a{
          text-decoration: none;
          color: #B2000093;
      }
      .row.bl div.col-sm-2 p{
          font-size: 9px;
          font-weight: bold;
      }
      .row.bl div.col-sm-2 a{
          text-decoration: none;
          color: #B2000093;
      }
      .row.bl{
          padding-bottom: 50px;
      }
      
      /* .row.ads div.col-sm-3{
      display:none;
  } */
      
      .row.ads{
                  background: #bababb5e;
                  margin-top: 0px;
                  padding-top: 50px;
                  padding-bottom: 100px;
              }
      .row.ads .container{
                  width:68%;
              }
      .row.ads .container.cg{
                  width: 78%;
              }
              .row.ads h6{
                  color: #B2000093;
              }
              .row.ads a{
                  text-decoration: none;
                  color: #B2000093;
              }
              
              .row.ads .fa{
                  font-weight: bold;
                  color: #B2000093;
              }
              div.top-left {
              position: absolute;
              top: 15px;
              left: 0px;
              border-radius: 0;
              text-transform: lowercase;
          }
          div.top-left .btn.btn-primary {
              background: tomato;
              border: none;
              font-size: 11px;
              letter-spacing: 3px;
              padding: 5px 22px;
              border-radius: 0;
          }
          .row.ads .panel-default .panel-footer{
              height: 90px;
          }
          .row.ads .panel-default .panel-footer p{
              color:#171919d3;
              font-size: 12px;
              padding-top: 0px;
              padding-bottom: 10px;
              font-weight: bold;
          }
          .row.ads .panel-default .panel-footer p span{
              color:#171919d3;
              font-size: 10px;
              font-weight: normal;
          }
          .row.ads .panel-default .panel-footer small{
              color:#171919d3;
              font-size: 9px;
              font-weight: bold;
              padding-bottom: 0;
              margin-bottom: 0;
          }
          .row.ads .panel-default .panel-footer hr{
              padding-top: 0;
              margin-top: 0;
              margin-bottom: 0;
          }
              div.row.ads div.panel-default{
                  width: auto;
                  margin-bottom: 20px;
                  box-shadow: 10px 6px 6px 0 rgba(0, 0, 0, 0.2);
              }
              div.row.ads div.panel-default div.panel-body{
                  margin-bottom: 0;
                  height: 200px;
                  width: 200px;
                  padding: 0;
              }
      .col-sm-2 input.btn.btn-success{
          background: transparent;
          border: none;
          color: #f1f1f1;
          text-transform: lowercase;
          }
  .image {
    display: block;
    width: 100%;
    height: auto;
  }
  
  div.overlay {
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    height: 65%;
    width: 200px;
    opacity: 0;
    transition: .3s ease;
    background-color: #b20000bb;
    color: #eee;
  }
  div.overlay p{
      padding-top: 50px;
  }
  div.container.folio:hover div.overlay {
    opacity: 1;
  }
  
  a.icon i.fa.fa-plus-circle{
    color: #eee;
    font-size: 80px;
    position: absolute;
    left: 50%;
    font-weight: bold;
    top: 80px;
    padding-bottom: 0px;
    transform: translate(-50%, -50%);
    -ms-transform: translate(-50%, -50%);
    text-align: center;
  }
  div.container.folio {
    position: relative;
    width: 100%;
    margin: 0;
    padding: 0;
  }
              .panel-default .panel-footer{
                  margin-bottom: 0;
                  width:200px;
              }
              .panel-default .panel-footer .fa{
                  font-weight: bold;
                  color: #B20000;
  
              }
              .panel-default .panel-body img{
                  margin-bottom: 0;
                  height:200px;
                  width: 200px;
                  background: #171919;
              }
   /* Bottom left text */
   .bottom-left {
              position: absolute;
              bottom: 108px;
              left: 15px;
              background: #f1f1f1;
              color: #b20000;
              padding-left: 15px;
              padding-right: 15px;
              z-index: 99;
          }
          /* Bottom right text */
   div.bottom-right {
              position: absolute;
              bottom: 80px;
              left: 158px;
              color: #f1f1f1;
              padding-left: 15px;
              padding-right: 15px;
              z-index: 99;
          }
   div.bottom-right:hover {
              position: absolute;
              bottom: 80px;
              left: 158px;
              color: #f1f1f1;
              padding-left: 15px;
              padding-right: 15px;
              z-index: 99;
          }
          .bottom-right form button{
              background: #f1f1f1;
              border-radius: 10px;
              color: #f1f1f1;
              border: none;
              z-index: 99;
          } 
          .bottom-right form button:hover{
              background: #f1f1f1;
              border-radius: 10px;
              color: #f1f1f1;
              border: none;
              z-index: 99;
          } 
      h2.title{
          color: #171919;
          font-weight: bold;
          padding-top: 20px;
          padding-bottom: 20px;
      }
      a.btn.btn-success{
          background: transparent;
          border: #B20000 solid 1px;
          color: #B20000;
          border-radius: 0;
          margin-top: 20px;
      }
      a.btn.btn-success:hover{
          background: #B20000;
          border: #B20000 solid 1px;
          color: #f1f1f1;
          border-radius: 3px;
      }
      
          
      .overlay1 {
            height: 100%;
            width: 0;
            position: fixed;
            z-index: 100;
            top: 0;
            left: 0;
            background-color: #b20000bb;
            overflow-x: hidden;
            transition: 0.5s;
          }
          
          .overlay-content {
            position: relative;
            top: 5%;
            width: 100%;
            text-align: center;
            margin-top: 30px;
          }
          .overlay-content img{
              width: 100px;
              height: 100px;
              padding-left: 20px;
          }
          
          .overlay1 a {
            padding: 8px;
            text-decoration: none;
            font-size: 36px;
            color: #818181;
            display: block;
            transition: 0.3s;
          }
          
          .overlay1 a:hover, .overlay1 a:focus {
            color: #f1f1f1;
          }
          
          div.overlay1 a.closebtn {
            position: absolute;
            top: 0px;
            right: 45px;
            font-size: 60px;
            color: #f1f1f1;
          }
          div.overlay1 h2.text-center.title {
            color: #f1f1f1;
          }
          h5 span{
              font-size:30px;
              margin-right:200px;
              cursor:pointer;
          }
          /* @media only screen and (max-width: 600px) {
     
              .row.ads .container{
                  width: 90%;
              }
     } */
@media only screen and (max-width: 700px) {
     
    .row.ads .container{
        /* width: 90%; */
        /* text-align: center; */
    }
    div.container.folio {
    position: relative;
    width: 100%;
    margin: 0;
    padding-right: 10px;
    padding-left: 10px;
  }
   div.row.ads div.panel-default div.panel-body{
             margin-bottom: 0;
             height: 350px !important;
             width: 350px !important;
             padding: 0;
         }
         div.row.ads div.panel-default{
             width: 350px !important;
             margin-bottom: 20px;
             box-shadow: 10px 6px 6px 0 rgba(0, 0, 0, 0.2);
         }
         .panel-default .panel-footer{
             margin-bottom: 0;
             width: 350px !important;
             padding-bottom: 95px;
         }
         .panel-default .panel-footer .fa{
             font-weight: bold;
             color: #B20000;
 
         }
         .panel-default .panel-body img{
             margin-bottom: 0;
             height:350px !important;
             width: 350px !important;
         }
              
          .row.ads .panel-default .panel-footer p{
              color:#171919d3;
              font-size: 15px !important;
              padding-top: 0px;
              padding-bottom: 10px;
              font-weight: bold;
          }
              .row.ads .panel-default .panel-footer p span{
              color:#171919d3;
              font-size: 15px !important;
              font-weight: normal;
          }
          .row.ads .panel-default .panel-footer small{
              color:#171919d3;
              font-size: 17px !important;
              font-weight: bold;
              padding-bottom: 0;
              margin-bottom: 0;
          }
    .bottom-left {
              position: absolute;
              bottom: 150px !important;
              left: 0px !important;
              background: #f1f1f1;
              color: #b20000;
              padding-left: 15px;
              padding-right: 15px;
              z-index: 99;
          }
          /* Bottom right text */
   div.bottom-right {
              position: absolute;
              bottom: 100px !important;
              left: 0px !important;
              color: #f1f1f1;
              padding-left: 15px;
              padding-right: 15px;
              z-index: 99;
          }
}
@media only screen and (max-width: 999px) { 
div.row.ads div.panel-default div.panel-body{
            margin-bottom: 0;
            height: 400px;
            width: 400px;
            padding: 0;
        }
        div.row.ads div.panel-default{
            width: 400px;
            margin-bottom: 20px;
            box-shadow: 10px 6px 6px 0 rgba(0, 0, 0, 0.2);
        }
        .panel-default .panel-footer{
            margin-bottom: 0;
            width: 400px;
            padding-bottom: 95px;
        }
        .panel-default .panel-footer .fa{
            font-weight: bold;
            color: #B20000;

        }
        .panel-default .panel-body img{
            margin-bottom: 0;
            height:400px;
            width: 400px;
        }
        .row.ads .container{
                  width: 70%;
                  margin: 0;
              }
}
@media only screen and (max-width: 1200px) { 
            
          .overlay-content img{
              width: 50px;
              height: 50px;
              padding-left: 0px;
              padding-right: 0px;
          }
              
      .col-sm-2 input.btn.btn-success{
          background: transparent;
          border: none;
          color: #f1f1f1;
          font-size: 8px;
          font-weight: bold;
          text-transform: lowercase;
          }
            .overlay a {
                font-size: 20px
                }
            .overlay .closebtn {
            font-size: 40px;
            top: 15px;
            right: 35px;
            }
      h2.title{
          color: #171919;
          font-weight: bold;
          padding-top: 20px;
          padding-bottom: 20px;
          font-size: 15px;
      }
      .row.bl div.col-sm-2{
          float: left;
          width: 33.33%;
      }
      div.row.bl div.col-sm-2 p{
          font-size: 12px;
          font-weight: bold;
      }
      .overlay1 div.col-sm-2{
          float: left;
          width: 33.33%;
      }
      div.overlay1 div.col-sm-2 p{
          font-size: 5px;
          color: #f1f1f1;
          font-weight: normal;
      }
      
      .col-sm-2 input.btn.btn-success{
          background: transparent;
          border: none;
          font-size: 6px;
          color: #f1f1f1;
          margin-right: 100px;
          text-transform: lowercase;
          }
      .row.bl{
          padding-left: 20px;
          padding-right: 20px;
          padding-bottom: 50px;
      }
      .row.bl img{
          margin-bottom: 10px;
          height: 160px;
          width: 160px;
          margin-left: 0px;
      }
      .row.bl div.panel.add img{
          height: 360px;
          width: 350px;
          box-shadow:none;
      }
      .row.bl div.panel{
          
          padding: 40px 50px;
          box-shadow: none;
          border-radius: 0;
      }
      .row.bl div.panel.add{
          
          padding:0;
          box-shadow: none;
          border-radius: 0;
      }
       /* .container.ads div.col-sm-3{
          float: left;
          width: 25%;
              } */
      .row.ads .container{
                  width: 100%;
              }
          .row.ads .panel-default .panel-footer p{
              color:#171919d3;
              font-size: 10px;
              padding-top: 0px;
              padding-bottom: 10px;
              font-weight: bold;
          }
          .row.ads .panel-default .panel-footer p span{
              color:#171919d3;
              font-size: 10px;
              font-weight: normal;
          }
          .row.ads .panel-default .panel-footer small{
              color:#171919d3;
              font-size: 10px;
              font-weight: normal;
              padding-bottom: 0;
              margin-bottom: 0;
          }
          
   /* Bottom left text */
   .bottom-left {
              position: absolute;
              bottom: 108px;
              left: 8px;
              background: #f1f1f1;
              color: #b20000;
              padding-left: 15px;
              padding-right: 15px;
              z-index: 99;
          }
          /* Bottom right text */
   div.bottom-right {
              position: absolute;
              bottom: 100px;
              left: 100px;
              color: #f1f1f1;
              padding-left: 15px;
              padding-right: 15px;
              z-index: 99;
          }
   div.bottom-right:hover {
              position: absolute;
              bottom: 80px;
              left: 108px;
              color: #f1f1f1;
              padding-left: 15px;
              padding-right: 15px;
              z-index: 99;
          }
          .bottom-right form button{
              background: #f1f1f1;
              border-radius: 10px;
              color: #f1f1f1;
              border: none;
              z-index: 99;
          } 
          .bottom-right form button:hover{
              background: #f1f1f1;
              border-radius: 10px;
              color: #f1f1f1;
              border: none;
              z-index: 99;
          } 
  div.overlay {
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    height: 50%;
    width: 150px;
    opacity: 0;
    transition: .3s ease;
    background-color: #b20000bb;
    color: #eee;
  }
    div.row.ads div.panel-default div.panel-body{
        margin-bottom: 0;
        height: 300px;
        width: 300px;
        padding: 0;
    }
    div.row.ads div.panel-default{
        width: 300px;
        margin-bottom: 20px;
        box-shadow: 10px 6px 6px 0 rgba(0, 0, 0, 0.2);
    }
    .panel-default .panel-footer{
        margin-bottom: 0;
        width: 300px;
        padding-bottom: 95px;
    }
    .panel-default .panel-footer .fa{
        font-weight: bold;
        color: #B20000;

    }
    .panel-default .panel-body img{
        margin-bottom: 0;
        height:300px;
        width: 300px;
    }
      div.jumbotron .container p{
          font-size: 10px;
          line-height: 1.8em;
      }
      div.jumbotron .col-sm-5 input{
          height: 39px;
          background: #f1f1f1;
          padding: 15px 20px;
          border: none;
          width: 100%;
      }
      
      .overlay1 .btn.btn-success{
          background: #f1f1f1;
          color: #b20000;
          font-size: 10px;
      }
      .sticky1 {
                position: fixed;
                top: 100px;
                bottom: 100px;
                z-index: 99;
                color: #b20000;
                margin-right: 0px;
                margin-left: 500px;
              } 
              h5.ct{
                color: #b20000;
                margin-left: 20px;
              } 
          h5 span{
              font-size:13px;
              margin-right:200px;
              cursor:pointer;
          }
  
      }
    </style>  <?php /**PATH E:\xampp\htdocs\Amaslink\resources\views/inc/css/home.blade.php ENDPATH**/ ?>