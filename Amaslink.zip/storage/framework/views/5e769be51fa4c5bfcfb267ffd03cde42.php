
<style>
    label{
        font-family: 'Fira Code', monospace;
    }
    div.container.create{
        margin-top:50px; 
        padding-bottom:200px;
        width:70%;
    }
    h1.create{
        margin-bottom: 50px;
    }
    .btn.btn-success {
    background: #b20000;
    border: none;
    font-size: 11px;
    border-radius: 0;
    }
    .btn.btn-success:hover {
    background: transparent;
    border: 1px solid #b20000;
    font-size: 11px;
    border-radius: 0;
    color: #B20000;
    }
    #main {
      transition: margin-left .5s;
      padding: 16px;
    }
    @media only screen and (max-width: 768px) {   
        
        div.container.create{
            margin-top:50px; 
            padding-bottom:10px;
            width:80%;
            border: 1px solid #f9f9f9;
            background: #f9f9f9;
            padding-top: 10px;
            margin-bottom: 50px;
        }
        div.container.create .row{
            margin-top:20px; 
            padding-bottom:100px;
            width:100%;
            border:none;
            background: white;
            padding-top: 30px;
            margin-left: 0px;
        }
           
    }
    </style><?php /**PATH E:\xampp\htdocs\Amaslink\resources\views/inc/css/create.blade.php ENDPATH**/ ?>