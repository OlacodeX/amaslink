
<style>

    .panel-default{
    border-radius: 0;
    box-shadow: 0 5px 5px 0 rgba(0, 0, 0, 0.2);
    border: none;
    }
    .panel-default.ad{
    border-radius: 0;
    margin-top: 20px;
    border: none;
    box-shadow: 0 5px 5px 0 rgba(0, 0, 0, 0.2);
    }
    .panel-default.ad a{
    text-decoration: wavy;
    color: #b20000;
    }
    .panel-default.ad .panel-heading{
    padding-top: 30px;
    padding-bottom: 30px;
    }
    .panel-body p,
    .panel-body span{
    font-size: 13px;
    }
    .panel-body a{
    text-decoration: wavy;
    color: #b20000;
    }
    .panel-heading h3,
    .panel-heading span{
    color: #b20000;
    }
input.btn.btn-default{
background: transparent;
border-radius: 0;
font-size: 13px;
border: 1px solid #b20000;
color: #b20000;
margin-bottom: 10px;
}
        li{
            list-style: square;
            color: #b20000;
        }

        .col-sm-3 li a{
text-decoration: none;
color: #b20000;
}
.row.forum{
    padding-top: 80px;
}
.page-item.active .page-link {
z-index: 1;
color: #fff;
background-color: #b20000;
border-color: #b20000;
}
.page-item .page-link {
color: #b20000;
}
div.col-sm-4.two{
    position: absolute;
    left:-999px;
}
    @media only screen and (max-width: 768px) {
div.col-sm-4.two{
    position: relative;
    left:0;
}
    
div.col-sm-4{
    position: absolute;
    left:-999px;
}
}
</style><?php /**PATH E:\xampp\htdocs\Amaslink\resources\views/inc/css/forum.blade.php ENDPATH**/ ?>