
<?php $__env->startSection('page_title'); ?>
<?php echo e(config('app.name')); ?>- Best Free Classified Ads | Ad Packs
<?php $__env->stopSection(); ?>
<?php echo $__env->make('inc.css.auction', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('inc.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container top text-center">
    <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <h3 class="title"><span>AMASLINK</span> CLASSIFIED ADS</h3>
   <small>
        
        Reach out to your target audience faster. On amaslink, we offer you a platform with an audience from over
        195 countries.
    </small>
</div>
<div class="container pricing">
    <div class="row">
        <div class="col-sm-4 text-center">
            <div class="panel-default text-center one">
                    <img src="img/service.png" alt="">
                    <div class="panel-body">
                        <h4>Things to know</h4>
                        <li>Users who wish to give their Ads top priority (i.e to appear on top of recent Ads)  can do this anytime by using the boost Ads button on their dashboard. This comes with an additional cost of $3.</li>
                    </div>
            </div>

        </div>
        <?php
            $amount1 = $_POST['amount1'];
            $amount2 = $_POST['amount2'];
        ?>
        <div class="col-sm-4 text-center">
            <div class="panel-default text-center">
                <div class="panel-body">
                    <h4 class="">Normal Package</h4>
      
                    <h2><span>$</span><?php echo e($amount1); ?>,00</h2>
                        <ul>
                            <li><i class="fa fa-check"></i>Never Expire</li>
                            <li><i class="fa fa-check"></i>Up To 195 Countries</li>
                            <li><i class="fa fa-close"></i>Priority Listing</li>
                            <li><i class="fa fa-check"></i>Up To 5 AD Images</li>
                            <li><i class="fa fa-check"></i>AD Video</li>
                        </ul>
                    <hr class="hrr">
                    <p class="text-center">
                        <?php echo Form::open(['action' => 'PaymentController@auction', 'method' => 'POST']) /** The action should be the block of code in the store function in PostsController
                        **/; ?>

                         <?php echo e(Form::hidden('amount', $amount1)); ?>

                         <?php echo e(Form::submit('Subscribe To Package', ['class' => 'btn btn-success', 'name' => 'submit','style' => 'text-transform:uppercase;'])); ?>

                        <?php echo Form::close(); ?>

                    </p>
                </div>
            </div>
        </div>
        
        <div class="col-sm-4 text-center">
            <div class="panel-default text-center">
                <div class="panel-body">
                    <h4 class="">Boosted Package</h4>
      
                    <h2><span>$</span><?php echo e($amount2); ?>,00</h2>
                        <ul>
                            <li><i class="fa fa-check"></i>Never Expire</li>
                            <li><i class="fa fa-check"></i>Priority Listing</li>
                            <li><i class="fa fa-check"></i>Up To 195 Countries</li>
                            <li><i class="fa fa-check"></i>Up To 5 AD Images</li>
                            <li><i class="fa fa-check"></i>AD Video</li>
                        </ul>
                    <hr class="hrr">
                    <p class="text-center">
                        <?php echo Form::open(['action' => 'PaymentController@auction', 'method' => 'POST']) /** The action should be the block of code in the store function in PostsController
                        **/; ?>

                         <?php echo e(Form::hidden('amount', $amount2)); ?>

                         <?php echo e(Form::submit('Subscribe To Package', ['class' => 'btn btn-success', 'name' => 'submit','style' => 'text-transform:uppercase;'])); ?>

                        <?php echo Form::close(); ?>

                    </p>
                </div>
            </div>
        </div>
</div>
</div>

<?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainone', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Amaslink\resources\views/pages/auction.blade.php ENDPATH**/ ?>