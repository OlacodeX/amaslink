<?php $__env->startSection('page_title'); ?>
<?php echo e(config('app.name')); ?> - Best Free Classified Ads
<?php $__env->stopSection(); ?>
<?php echo $__env->make('inc.css.list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row main">
        <?php echo $__env->make('inc.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<div class="row ads">
    <div class="container text-justify">
        <h2 class="title text-center">ALL LISTINGS</h2>
        <h6 class="text-center"> BUY & SELL ANYTHING</h6>
        <?php if(count($listings_all) > 0): ?>
            <?php $__currentLoopData = // Loop through them
                $listings_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="listings/<?php echo e($listing->id); ?>" title="">
            <div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
                <div class="container folio">
                <div class="panel-default">
                    <div class="panel-body">
                        <div class="bottom-left">
                            <i class="fa fa-eye"></i><span><?php echo e(App\Models\ListingView::where('listings_id', $listing->id)->count()); ?></span>
                        </div>
                        <div class="bottom-right">
                            <?php echo e(Form::open(array('action' => 'ListingsController@bookmark'))); ?>  
                            <?php echo e(Form::hidden('id', $listing->id)); ?> 
                            <?php echo e(Form::hidden('title', $listing->title)); ?>

                            <?php echo e(Form::hidden('image', $listing->image1)); ?>

                            <?php echo e(Form::hidden('type', $listing->type)); ?>

                            <?php if(auth()->guard()->guest()): ?>
                            <button type="submit" onclick="myFunction(this)" class="fa fa-heart-o" title="Bookmark"></button>
                            <?php else: ?> 
                            <?php if(empty(App\Models\Favorite::where('user_id', '=',  auth()->user()->id)->where('listing_id', '=',  $listing->id)->first())): ?>
                            
                            <button type="submit" onclick="myFunction(this)" class="fa fa-heart-o" title="Bookmark"></button>
                            <?php else: ?>
                            <button type="submit" onclick="myFunction(this)" class="fa fa-heart" title="Remove Bookmark"></button>
                            <?php endif; ?>
                            <?php endif; ?>
                            
                            <?php echo e(Form::close()); ?>

                        </div>
                        <?php if(!empty($listing->image1)): ?>
                        <img src="<?php echo e(URL::to('img/cover_images/listings/'.$listing->image1)); ?>" class="img-responsive" alt="">
                        <?php else: ?>
                        <img src="<?php echo e(URL::to('img/AMAS.png')); ?>" class="img-responsive" alt="">
                            
                        <?php endif; ?>
                    </div>
                    <div class="panel-footer">
                        <small class="text-justify"><i class="fa fa-cubes"></i><?php echo Str::words($listing->title,5); ?></small>
                        <hr>
                        <p class="text-justify">
                            <?php if(!empty($listing->country)): ?>
                            <i class="fa fa-map-marker"></i><?php echo e($listing->country); ?>

                            <?php endif; ?>     
                            <?php if(!empty($listing->price)): ?>
                            | <span>$</span><?php echo e($listing->price); ?>

                            <?php endif; ?>
                            
                            
                        </p>
                        
                    </div>
                    <?php if($listing->type === 'paid'): ?>
                        
                    <div class="top-left">
                        <span class="btn btn-primary">FEATURED</span>
                    </div>
                    <?php endif; ?>
                </div>
                </div>
            </div>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
        <div class="text-center">
            
            <div class="d-flex justify-content-center" style="padding-bottom:10px">
                
                <?php if($listings_all->currentPage() > 1): ?>
                    <a href="<?php echo e($listings_all->previousPageUrl()); ?>" class="btn btn-primary pagination">Previous</a>
                <?php endif; ?>

                <?php if($listings_all->hasMorePages()): ?>
                    <a href="<?php echo e($listings_all->nextPageUrl()); ?>" class="btn btn-primary pagination">Next</a>
                <?php endif; ?>
                
            </div>
    <?php else: ?>
            <p class="text-center">No Items Yet <br> <a class="btn btn-success" href="<?php echo e(URL::previous()); ?>">Go back</a></p>
    <?php endif; ?>
        </div>
</div>
</div>

<div class="row">
    <?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<script>
    function myFunction(x) {
    x.classList.toggle("fa fa-bookmark");
}
var msg = '<?php echo e(Session::get('alert')); ?>';
var exist = '<?php echo e(Session::has('alert')); ?>';
if (exist) {
    alert(msg);
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainone', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Amaslink\resources\views/pages/list.blade.php ENDPATH**/ ?>