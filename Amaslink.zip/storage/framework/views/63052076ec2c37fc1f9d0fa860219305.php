
<style>
    div.jumbotron.text-center{
        color:antiquewhite;
        background-size: cover;
        background-position: center;
        background-attachment: fixed;
        margin-top: 0px;
        padding-top: 100px;
        padding-bottom: 100px;
        border-radius: 0;
        margin-bottom: 100px;
}
    .jumbotron.text-center p{
        font-size: 15px;
}
.panel-default{
    border-radius: 0;
    box-shadow: 0 5px 5px 0 rgba(0, 0, 0, 0.2);
    border: none;
    }
    .panel-default.ad{
    border-radius: 0;
    margin-top: 20px;
    border: none;
    }
    .panel-default.ad a{
    text-decoration: wavy;
    color: #b20000;
    }
    .panel-default.ad .panel-heading{
    padding-top: 30px;
    padding-bottom: 30px;
    }
    .panel-body p,
    .panel-body span{
    font-size: 13px;
    }
    .panel-body a{
    text-decoration: wavy;
    color: #b20000;
    }
    .panel-heading h3,
    .panel-heading span{
    color: #b20000;
    }
    .col-sm-3.img1 img{
        height: 500px;
        width: 390px;
        padding-right: 20px;
}
    .col-sm-6.img2 img{
        height: 250px;
        padding-left: 20px;
        margin-top: 50px;
}
    .col-sm-6.img2 h2{
        padding-top: 30px;
        padding-left: 20px;
        font-size: 22px;
}
    .col-sm-6.img2 p,
    .col-sm-6.img2 small{
        padding-left: 20px;
        text-align: justify;
}
.col-sm-3.last{
        padding-left: 50px;
}
.col-sm-3.last li{
      padding-bottom: 10px;
}
.col-sm-3.last li a{
text-decoration: none;
}
input.btn.btn-default{
background: transparent;
border-radius: 0;
font-size: 13px;
border: 1px solid #b20000;
color: #b20000;
margin-bottom: 10px;
}

span.glyphicon{
margin-top: 0px;
padding-right: 160px;
font-size: 15px;
color: #545454;
}
button.fa.fa-bookmark-o{
background: transparent;
border-radius: 0;
font-size: 13px;
color: #b20000;
border: none;
margin-bottom: 10px;
}
div.col-sm-3 input{
width: 200px;
border-radius: 0px;
background: rgba(196, 194, 194, 0.178);
border: none;
}
a.pull-left{
    margin-left: 20px;
    border-radius: 0;
    margin-bottom: 30px;
}
a.btn-info{
border: 1px solid #b20000;
color: #f1f1f1;
    border-radius: 0;
    background: #b20000;
    margin-top: 20px;
    margin-bottom: 30px;
}
a.btn-info:hover{
    background: transparent;
    border: 1px solid #b20000;
    color: #b20000;
}
h3.title,
h2.title{
        color: #171919;
        font-weight: bold;
}
h2.titlem{
        color: #f1f1f1;
        font-weight: bold;
}
        li{
            list-style: square;
            color: #b20000;
        }
        .col-sm-3 li a{
text-decoration: none;
color: #b20000;
}

.col-sm-6 .page-item.active .page-link {
z-index: 1;
color: #fff;
background-color: #b20000;
border-color: #b20000;
}
.col-sm-6 .page-item .page-link {
color: #b20000;
}
.col-sm-6 p{
text-align: justify;
padding-top: 10px;
padding-right: 80px;
    }
        div.top-left .btn.btn-primary {
            background: tomato;
            border: none;
            font-size: 11px;
            letter-spacing: 3px;
            padding: 6px 22px;
            border-radius: 0;
            margin-left: 10px;
            color: #171919;
            font-weight: bold;
        }
        @media only screen and (max-width: 768px) {
        
    .col-sm-3.img1 img{
        height: 300px;
        width: 300px;
        padding-right: 0px;
        margin-left: 30px;
        margin-bottom: 10px;
} 
    .col-sm-6.img2 h2{
        padding-top: 30px;
        padding-left: 20px;
        padding-right: 20px;
}
    .col-sm-6.img2 p,
    .col-sm-6.img2 small{
        padding-left: 20px;
        padding-right: 20px;
        text-align: justify;
}
    .col-sm-6.img2 img{
        height: 300px;
        width: 330px;
        padding-right: 0px;
        margin-left: 6px;
        margin-bottom: 10px;margin-top: 100px;
}
.col-sm-3.last{
        padding-left: 50px;
        padding-top: 100px;
}
    .jumbotron.text-center p{
        padding: 5px 50px 5px 50px;
}

}
</style><?php /**PATH E:\xampp\htdocs\Amaslink\resources\views/inc/css/index.blade.php ENDPATH**/ ?>