
<style>
    body{
                margin: 0;
                padding: 0;
                background-attachment: fixed;
                overflow-x: hidden;
                height: 100%;
                width: 100%;
                color: antiquewhite;
                font-family: 'Grenze', serif;
            }
            
    
    input.btn.btn-success{
        background: #B20000;
        color: #f1f1f1;
        border-radius: 0;
        margin-top: 20px;
    }
    input.btn.btn-success:hover{
        background: transparent;
        border: #B20000 solid 1px;
        color: #B20000;
        border-radius: 10px;
    }
            .row.icon .fa{
                font-size: 50px;
                padding-bottom: 40px;
            } 
    p.social .fa{
        font-size: 100px;
        padding: 4px;
        padding-top: 0;
        padding-bottom: 0;
        padding-left: 70px;
    }
                 
    p.social .fa:hover{
        font: normal;
        font-size:80px;
    }
            .container-fluid.contact{
                box-shadow: 0 10px 12px 0 rgba(0, 0, 0, 0.2);
                color:#b20000;
                background:#FEFDFD;
            }
            .container.top span.float{
              float:right;
            }
            h3.contact,
            h3.connect{
                padding-top: 100px;
                margin-bottom: 30px;
                padding-left: 50px;
                color:#171919;
                font-weight: bold;
            }
    .row.cont .col-sm-6 input{
        height: 60px;
        padding: 15px 20px;
        border: none;
    }
    .row.icon{
        padding-bottom: 80px;
    }
    
    .row.icon a,
    .row.icon small{
    font-weight: bold;
    text-decoration: none;
    color: #b20000;
}
    @media only screen and (max-width: 768px) {
      /* For mobile phones: */
            h3.contact{
                padding-top: 100px;
                text-align: justify;
                padding-left: 10px;
            }
   .row.icon div.col-sm-3{
        float: left;
        width: 50%;
    }
    p.social .fa{
        font-size: 80px;
        padding: 4px;
        padding-top: 0;
        padding-bottom: 0;
        padding-left: 70px;
    }
                 
    p.social .fa:hover{
        font: normal;
        font-size:50px;
    }
            h3.contact{
                padding-top: 100px;
                margin-bottom: 30px;
                padding-left: 50px;
                color:#171919;
                font-weight: bold;
            }

            h3.connect{
                padding-top: 100px;
                margin-bottom: 30px;
                padding-left: 30px;
                color:#171919;
                font-weight: bold;
            }
            
    }
    </style>
    <?php /**PATH E:\xampp\htdocs\Amaslink\resources\views/inc/css/contact.blade.php ENDPATH**/ ?>