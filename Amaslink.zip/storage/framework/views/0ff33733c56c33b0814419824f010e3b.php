
<?php $__env->startSection('page_title'); ?>
<?php echo e(config('app.name')); ?> - Best Free Classified Ads | Forum
<?php $__env->stopSection(); ?>
<?php echo $__env->make('inc.css.forum', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('inc.navother', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row forum">
        <div class="container">
            <h3 class="text-center title" style="padding-bottom:20px;">JOIN THE <span>DISCUSSION</span></h3>
            <div class="col-sm-4">
               <a href=""><img src="img/add.png" alt="" class="img-responsive"></a> 
                <div class="panel-group">
                    <div class="panel panel-default ad">
                        <a data-toggle="collapse" href="#collapse1">
                        <div class="panel-heading">
                            <h4 class="panel-title text-center">
                            Safety Tips
                            </h4>
                        </div>
                        </a>
                      <div id="collapse1" class="panel-collapse collapse in">
                        <div class="panel-body">
                            <ul>
                                <li>Meet seller at a safe location</li>
                                <li>Check the item before you buy</li>
                                <li>Pay only after collecting item</li>
                            </ul>
                        </div>
                      </div>
                    </div>
                  <div class="panel panel-default ad">
                      <a data-toggle="collapse" href="#collapse2">
                      <div class="panel-heading">
                          <h4 class="panel-title text-center"> How To Post Ads</h4>
                      </div>
                      </a>
                    <div id="collapse2" class="panel-collapse collapse">
                      <div class="panel-body">
                        <li>Click on <a href="">Post Ad For FREE NOW</a></li>
                        <li>You will be immediately redirected to our Login page (if you are not a registered user). You will have to fill out all the required fields and click on ‘Register’ button at the bottom of the page.</li>
                        <li>After Registering, Complete all the required information about your item.</li>
                        <li>After filling out the required fields, click on “Post” button.</li>
                        <li>Once you post your ad Your advert will be published shortly once moderation process is completed.</li>
                        <li>Once your advert is live, you will receive a notification email.</li>
                        <li>Be ready to receive numerous incoming calls from your potential buyers. Good luck with your sales!</li>
                        <li>You can have a look at our premium packages also for more sales and boost packages!</li>
        
                      </div>
                    </div>
                  </div>
                </div>
            </div>
            <div class="col-sm-5">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3>Forum Topics</h3>
                    <small style="color: #b20000;">To comment on a topic click on it.</small>

                    </div>
                    <div class="panel-body">
                        <?php if(
                            //if there is data in the db
                        count($topics) > 0
                        ): ?>
                        <?php $__currentLoopData = // Loop through them
                            $topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('communities.show', $topic->slug)); ?>" style="text-decoration:none;color:#b20000;">
                        <li style="text-transform: uppercase;"><?php echo e($topic->topic); ?></li> 
                        </a>
                        <span><i class="fa fa-clock-o"></i><?php echo e($topic->created_at); ?></span> <span> <i class="fa fa-user"></i><?php echo e($topic->user_name); ?></span>
                        
                        <hr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
                        <div class="col-md-12" style="text-align:right;">
                                <!-----The pagination link----->
                                <?php echo e($topics->links()); ?>

                        </div>
                            <?php else: ?>
                            <p>No post found</p>
                                
                            <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="col-sm-4 two">
                <a href=""><img src="img/add.png" alt="" class="img-responsive"></a> 
                 <div class="panel-group">
                     <div class="panel panel-default ad">
                         <a data-toggle="collapse" href="#collapse3">
                         <div class="panel-heading">
                             <h4 class="panel-title text-center">
                             Safety Tips
                             </h4>
                         </div>
                         </a>
                       <div id="collapse3" class="panel-collapse collapse in">
                         <div class="panel-body">
                             <ul>
                                 <li>Meet seller at a safe location</li>
                                 <li>Check the item before you buy</li>
                                 <li>Pay only after collecting item</li>
                             </ul>
                         </div>
                       </div>
                     </div>
                   <div class="panel panel-default ad" style="margin-bottom: 50px;">
                       <a data-toggle="collapse" href="#collapse4">
                       <div class="panel-heading">
                           <h4 class="panel-title text-center"> How To Post Ads</h4>
                       </div>
                       </a>
                     <div id="collapse4" class="panel-collapse collapse">
                       <div class="panel-body">
                         <li>Click on <a href="">Post Ad For FREE NOW</a></li>
                         <li>You will be immediately redirected to our Login page (if you are not a registered user). You will have to fill out all the required fields and click on ‘Register’ button at the bottom of the page.</li>
                         <li>After Registering, Complete all the required information about your item.</li>
                         <li>After filling out the required fields, click on “Post” button.</li>
                         <li>Once you post your ad Your advert will be published shortly once moderation process is completed.</li>
                         <li>Once your advert is live, you will receive a notification email.</li>
                         <li>Be ready to receive numerous incoming calls from your potential buyers. Good luck with your sales!</li>
                         <li>You can have a look at our premium packages also for more sales and boost packages!</li>
         
                       </div>
                     </div>
                   </div>
                 </div>
             </div>
            <div class="col-sm-3">
                <h3 class="title">Watch Live Videos From Amaslink Channel</h3>
                <hr class="hrr">
                <iframe src="https://www.youtube.com/embed/live_stream?channel=UCtr6z1xfyPLNSzzYUwMZCvQ" width="300" height="400"></iframe>
                <h3 class="title">Categories</h3>
            <hr class="hrr">
            
            <?php echo Form::open(['action' => 'PagesController@category', 'method' => 'GET', 'id' => 'my_form_1']) /** The action should be the block of code in the store function in PostsController
            **/; ?>

                 <?php echo e(Form::hidden('category', 'CURRENCY TRADING')); ?>

                 <?php echo e(Form::submit('CURRENCY TRADING', ['class' => 'btn btn-default'])); ?>

                
            <?php echo Form::close(); ?>

            <?php echo Form::open(['action' => 'PagesController@category', 'method' => 'GET', 'id' => 'my_form_2']) /** The action should be the block of code in the store function in PostsController
            **/; ?>

                 <?php echo e(Form::hidden('category', 'MINERAL, CRUDE OIL')); ?>

                 <?php echo e(Form::submit('MINERAL/CRUDE OIL', ['class' => 'btn btn-default', 'style' => 'text-transform:uppercase;'])); ?>

                
               
                (<?php echo e(App\Models\Listings::where('category', 'MINERAL, CRUDE OIL')->where('status', 'approved')->count()); ?>)
           
            <?php echo Form::close(); ?>

            <?php echo Form::open(['action' => 'PagesController@category', 'method' => 'GET', 'id' => 'my_form_4']) /** The action should be the block of code in the store function in PostsController
            **/; ?>

                 <?php echo e(Form::hidden('category', 'BUSINESS SALES')); ?>

                 <?php echo e(Form::submit('BUSINESS SALES', ['class' => 'btn btn-default'])); ?>

                
            <?php echo Form::close(); ?>

            <?php echo Form::open(['action' => 'PagesController@category', 'method' => 'GET', 'id' => 'my_form_4']) /** The action should be the block of code in the store function in PostsController
            **/; ?>

                 <?php echo e(Form::hidden('category', 'MOBILE,ELECTRONICS')); ?>

                 <?php echo e(Form::submit('MOBILE,ELECTRONICS', ['class' => 'btn btn-default'])); ?>

                
            <?php echo Form::close(); ?>

            <?php echo Form::open(['action' => 'PagesController@category', 'method' => 'GET', 'id' => 'my_form_4']) /** The action should be the block of code in the store function in PostsController
            **/; ?>

                 <?php echo e(Form::hidden('category', 'JOBS')); ?>

                 <?php echo e(Form::submit('JOBS', ['class' => 'btn btn-default'])); ?>

                
            <?php echo Form::close(); ?>

            <?php echo Form::open(['action' => 'PagesController@category', 'method' => 'GET', 'id' => 'my_form_4']) /** The action should be the block of code in the store function in PostsController
            **/; ?>

                 <?php echo e(Form::hidden('category', 'REAL ESTATE, LANDS')); ?>

                 <?php echo e(Form::submit('REAL ESTATE, LANDS', ['class' => 'btn btn-default'])); ?>

                
            <?php echo Form::close(); ?>

            <?php echo Form::open(['action' => 'PagesController@category', 'method' => 'GET', 'id' => 'my_form_4']) /** The action should be the block of code in the store function in PostsController
            **/; ?>

                 <?php echo e(Form::hidden('category', 'AUTOMOBILES')); ?>

                 <?php echo e(Form::submit('AUTOMOBILES', ['class' => 'btn btn-default'])); ?>

                
            <?php echo Form::close(); ?>

            <?php echo Form::open(['action' => 'PagesController@category', 'method' => 'GET', 'id' => 'my_form_4']) /** The action should be the block of code in the store function in PostsController
            **/; ?>

                 <?php echo e(Form::hidden('category', 'KIDS AND BABIES')); ?>

                 <?php echo e(Form::submit('KIDS AND BABIES', ['class' => 'btn btn-default'])); ?>

                
            <?php echo Form::close(); ?>

            <?php echo Form::open(['action' => 'PagesController@category', 'method' => 'GET', 'id' => 'my_form_4']) /** The action should be the block of code in the store function in PostsController
            **/; ?>

                 <?php echo e(Form::hidden('category', 'SPORT')); ?>

                 <?php echo e(Form::submit('SPORT', ['class' => 'btn btn-default'])); ?>

                
            <?php echo Form::close(); ?>

            <h3 class="title">Tags</h3>
            <hr class="hrr">
            <a href="./Posts" class="btn btn-default">Blog</a>
            <a href="./communities" class="btn btn-default">Forum</a>
            <a href="./alllistings" class="btn btn-default">Ad Listings</a>
            <a href="./contact" class="btn btn-default">Talk To Us</a>
            </div>
        </div>
    </div>
    <div class="row">
        <?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <script>
        function myFunction(x) {
        x.classList.toggle("fa fa-bookmark");
    }
    var msg = '<?php echo e(Session::get('alert')); ?>';
    var exist = '<?php echo e(Session::has('alert')); ?>';
    if (exist) {
        alert(msg);
    }
    </script>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainone', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Amaslink\resources\views/pages/forum.blade.php ENDPATH**/ ?>